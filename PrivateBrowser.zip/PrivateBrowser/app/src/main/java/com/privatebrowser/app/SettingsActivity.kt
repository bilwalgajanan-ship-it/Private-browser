package com.privatebrowser.app

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.widget.doAfterTextChanged

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var engines: Engines
    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private var list = mutableListOf<Engine>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Settings"
        prefs = Prefs(this); engines = Engines(this); db = Db(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        build()
    }

    private fun header(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.parseColor("#B57EDC"))
            setPadding(0, dp(20), 0, dp(6))
        })
    }

    private fun field(label: String, value: String, onChange: (String) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply { text = label; textSize = 12f })
        box.addView(EditText(this).apply {
            setText(value)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            doAfterTextChanged { onChange(it?.toString() ?: "") }
        })
        return box
    }

    private fun toggle(label: String, v: Boolean, onChange: (Boolean) -> Unit): View =
        SwitchCompat(this).apply {
            text = label; isChecked = v
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun build() {
        root.removeAllViews()
        list = engines.all()

        header("General")
        root.addView(field("Home page", prefs.home) { prefs.home = it })
        root.addView(field("Custom user agent (blank = default)", prefs.ua) { prefs.ua = it })
        root.addView(toggle("Request desktop site", prefs.desktop) { prefs.desktop = it })
        root.addView(toggle("JavaScript enabled", prefs.js) { prefs.js = it })

        header("Search engines — use %s where the query goes")
        list.forEachIndexed { i, e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = e.name + "\n" + e.url; textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(button("Edit") { editEngine(i) })
            row.addView(button("Del") {
                if (list.size <= 1) toast("Keep at least one engine") else {
                    list.removeAt(i); engines.save(list)
                    if (engines.selected >= list.size) engines.selected = 0
                    build()
                }
            })
            root.addView(row)
        }
        root.addView(button("Add search engine") { editEngine(-1) })

        header("Local data (nothing is ever uploaded)")
        root.addView(button("Clear browsing history") { db.clearHistory(); toast("History cleared") })
        root.addView(button("Clear cookies, site data & cache") {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            WebView(this).clearCache(true)
            toast("Cleared")
        })
        root.addView(button("Delete all saved logins") {
            AlertDialog.Builder(this).setTitle("Delete all saved logins?")
                .setPositiveButton("Delete") { _, _ -> db.clearCreds(); toast("Deleted") }
                .setNegativeButton("Cancel", null).show()
        })
    }

    private fun editEngine(idx: Int) {
        val e = if (idx >= 0) list[idx] else Engine("", "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val n = EditText(this).apply { hint = "Name"; setText(e.name) }
        val u = EditText(this).apply {
            hint = "https://example.org/search?q=%s"; setText(e.url)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this)
            .setTitle(if (idx >= 0) "Edit engine" else "Add engine")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val name = n.text.toString().trim()
                val url = u.text.toString().trim()
                if (name.isEmpty() || !url.contains("%s")) {
                    toast("Name and a URL containing %s are required")
                } else {
                    if (idx >= 0) list[idx] = Engine(name, url) else list.add(Engine(name, url))
                    engines.save(list)
                    build()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
