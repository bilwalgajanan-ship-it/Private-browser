package com.privatebrowser.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Saved logins. Keys AND values are encrypted (AES-256-SIV / AES-256-GCM) with a master key held in the
 * Android Keystore. Data stays on the device: backups are disabled and there is no sync code.
 */
class SecureStore(ctx: Context) {
    data class Cred(val host: String, val user: String, val pass: String)

    private val p = EncryptedSharedPreferences.create(
        ctx, "secure_logins",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun save(host: String, user: String, pass: String) { p.edit().putString("$host|$user", pass).apply() }
    fun get(host: String, user: String): String? = p.getString("$host|$user", null)
    fun forHost(host: String): Cred? = all().firstOrNull { it.host == host }
    fun delete(c: Cred) { p.edit().remove("${c.host}|${c.user}").apply() }
    fun clear() { p.edit().clear().apply() }
    fun all(): List<Cred> = p.all.mapNotNull { (k, v) ->
        val i = k.indexOf('|')
        if (i < 0 || v !is String) null else Cred(k.substring(0, i), k.substring(i + 1), v)
    }.sortedBy { it.host }
}
