package com.privatebrowser.app

import android.net.Uri
import org.jsoup.Jsoup
import java.net.URLEncoder

fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

/** Queries several engines in parallel, extracts result links and merges them (reciprocal-rank fusion). */
object Merge {
    private class Hit(val title: String, val url: String)
    private class Agg(val title: String, val url: String) { var score = 0.0; val src = LinkedHashSet<String>() }

    private fun hostOf(u: String) = try { Uri.parse(u).host?.removePrefix("www.") ?: "" } catch (e: Exception) { "" }
    private fun base(h: String) = h.split(".").takeLast(2).joinToString(".")

    private fun searchUrl(e: Engine, q: String) = e.url.replace("%s", URLEncoder.encode(q, "UTF-8"))

    private fun fetch(e: Engine, q: String, ua: String): List<Hit> {
        var url = searchUrl(e, q)
        // DuckDuckGo's JS-free endpoint returns parseable results
        if (url.startsWith("https://duckduckgo.com/?q=")) url = url.replace("https://duckduckgo.com/?q=", "https://html.duckduckgo.com/html/?q=")
        val doc = Jsoup.connect(url).userAgent(ua).timeout(10000).followRedirects(true).ignoreHttpErrors(true).get()
        val engineBase = base(hostOf(url))
        val brand = engineBase.substringBefore('.')
        val seen = HashSet<String>()
        val out = ArrayList<Hit>()
        for (a in doc.select("a[href]")) {
            var link = a.absUrl("href")
            if (!link.startsWith("http")) continue
            val u = Uri.parse(link)
            (u.getQueryParameter("uddg") ?: if (u.path == "/url") u.getQueryParameter("q") else null)?.let { link = it }
            val h = hostOf(link)
            if (h.isEmpty() || h.contains(brand)) continue
            val t = a.text().trim()
            if (t.length < 10) continue
            if (!seen.add(link.substringBefore('#'))) continue
            out += Hit(t, link)
            if (out.size >= 20) break
        }
        return out
    }

    fun page(q: String, engines: List<Engine>, ua: String): String {
        val res = arrayOfNulls<List<Hit>>(engines.size)
        val threads = engines.mapIndexed { i, e ->
            Thread { res[i] = try { fetch(e, q, ua) } catch (t: Throwable) { emptyList() } }.apply { start() }
        }
        threads.forEach { it.join(20000) }
        val agg = LinkedHashMap<String, Agg>()
        engines.forEachIndexed { i, e ->
            (res[i] ?: emptyList()).forEachIndexed { rank, h ->
                val key = hostOf(h.url) + Uri.parse(h.url).path.orEmpty().trimEnd('/')
                val a = agg.getOrPut(key) { Agg(h.title, h.url) }
                a.score += 1.0 / (60 + rank)
                a.src += e.name
            }
        }
        val sb = StringBuilder()
        sb.append("""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
body{font-family:sans-serif;margin:0;padding:16px;background:#fff;color:#202124}
h2{font-size:16px;font-weight:500;margin:4px 0 16px}.r{margin-bottom:18px}
.r a{color:#1a0dab;font-size:17px;text-decoration:none;display:block;overflow-wrap:anywhere}
.d{color:#188038;font-size:13px;margin:2px 0}.b{display:inline-block;background:#e8f0fe;color:#1967d2;border-radius:10px;padding:1px 8px;font-size:11px;margin-right:4px}
.f{border-top:1px solid #dadce0;padding-top:12px;margin-top:8px;font-size:13px}.f a{color:#1a73e8;margin-right:12px}
@media(prefers-color-scheme:dark){body{background:#202124;color:#e8eaed}.r a{color:#8ab4f8}.d{color:#81c995}.b{background:#303134;color:#8ab4f8}.f{border-color:#3c4043}}
</style></head><body>""")
        sb.append("<h2>Merged results for &ldquo;${esc(q)}&rdquo; from ${engines.size} engine(s)</h2>")
        val sorted = agg.values.sortedByDescending { it.score }
        if (sorted.isEmpty()) sb.append("<p>No results could be extracted (engines may require JavaScript or show a captcha). Use the links below.</p>")
        for (a in sorted) {
            sb.append("<div class=r><a href=\"${esc(a.url)}\">${esc(a.title)}</a><div class=d>${esc(hostOf(a.url))}</div>")
            a.src.forEach { sb.append("<span class=b>${esc(it)}</span>") }
            sb.append("</div>")
        }
        sb.append("<div class=f>Open natively: ")
        engines.forEachIndexed { i, e ->
            sb.append("<a href=\"${esc(searchUrl(e, q))}\">${esc(e.name)} (${res[i]?.size ?: 0})</a>")
        }
        sb.append("</div></body></html>")
        return sb.toString()
    }
}
