package com.privatebrowser.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Row(val id: Long, val title: String, val sub: String)
data class Cred(val id: Long, val host: String, val user: String, val pass: String)
class TabRec(
    val url: String,
    val title: String,
    val scrollY: Int,
    val state: ByteArray?,
    val active: Boolean
)

/** Local-only SQLite: history, bookmarks, credentials (encrypted), tab sessions. */
class Db(private val ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "browser.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, title TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT UNIQUE, title TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE credentials(id INTEGER PRIMARY KEY AUTOINCREMENT, host TEXT, username TEXT, password TEXT, ts INTEGER, UNIQUE(host, username))")
        d.execSQL("CREATE TABLE tabs(pos INTEGER PRIMARY KEY, url TEXT, title TEXT, scroll INTEGER, state BLOB, active INTEGER)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun rows(sql: String, args: Array<String>? = null): List<Row> {
        val out = ArrayList<Row>()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out.add(Row(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: ""))
        }
        return out
    }

    // ---- history ----
    fun addHistory(url: String, title: String) {
        val v = ContentValues()
        v.put("url", url); v.put("title", title); v.put("ts", System.currentTimeMillis())
        writableDatabase.insert("history", null, v)
    }
    fun history(limit: Int = 300) = rows("SELECT id, title, url FROM history ORDER BY ts DESC LIMIT $limit")
    fun deleteHistory(id: Long) { writableDatabase.delete("history", "id=?", arrayOf(id.toString())) }
    fun clearHistory() { writableDatabase.delete("history", null, null) }

    // ---- bookmarks ----
    fun isBookmarked(url: String): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM bookmarks WHERE url=?", arrayOf(url)).use { it.moveToFirst() }

    /** @return true if the page is bookmarked after the call */
    fun toggleBookmark(url: String, title: String): Boolean {
        if (isBookmarked(url)) {
            writableDatabase.delete("bookmarks", "url=?", arrayOf(url))
            return false
        }
        val v = ContentValues()
        v.put("url", url); v.put("title", title); v.put("ts", System.currentTimeMillis())
        writableDatabase.insertWithOnConflict("bookmarks", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }
    fun bookmarks() = rows("SELECT id, title, url FROM bookmarks ORDER BY ts DESC")
    fun deleteBookmark(id: Long) { writableDatabase.delete("bookmarks", "id=?", arrayOf(id.toString())) }

    // ---- credentials (password column is AES-GCM encrypted via Vault) ----
    fun saveCred(host: String, user: String, pass: String) {
        val v = ContentValues()
        v.put("host", host); v.put("username", user)
        v.put("password", Vault.enc(ctx, pass)); v.put("ts", System.currentTimeMillis())
        writableDatabase.insertWithOnConflict("credentials", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun credExists(host: String, user: String, pass: String): Boolean =
        creds().any { it.host == host && it.user == user && it.pass == pass }

    fun creds(): List<Cred> {
        val out = ArrayList<Cred>()
        readableDatabase.rawQuery("SELECT id, host, username, password FROM credentials ORDER BY host", null).use { c ->
            while (c.moveToNext()) {
                val p = try { Vault.dec(ctx, c.getString(3)) } catch (e: Exception) { "" }
                out.add(Cred(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", p))
            }
        }
        return out
    }
    fun deleteCred(id: Long) { writableDatabase.delete("credentials", "id=?", arrayOf(id.toString())) }
    fun clearCreds() { writableDatabase.delete("credentials", null, null) }

    // ---- tab session ----
    fun saveTabs(list: List<TabRec>) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.delete("tabs", null, null)
            list.forEachIndexed { i, t ->
                val v = ContentValues()
                v.put("pos", i); v.put("url", t.url); v.put("title", t.title)
                v.put("scroll", t.scrollY); v.put("active", if (t.active) 1 else 0)
                if (t.state != null) v.put("state", t.state)
                d.insert("tabs", null, v)
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    fun loadTabs(): List<TabRec> {
        val out = ArrayList<TabRec>()
        try {
            readableDatabase.rawQuery("SELECT url, title, scroll, state, active FROM tabs ORDER BY pos", null).use { c ->
                while (c.moveToNext()) {
                    out.add(TabRec(
                        c.getString(0) ?: "", c.getString(1) ?: "", c.getInt(2),
                        if (c.isNull(3)) null else c.getBlob(3), c.getInt(4) == 1
                    ))
                }
            }
        } catch (e: Exception) { /* oversized row etc. -> start fresh */ }
        return out
    }
}
