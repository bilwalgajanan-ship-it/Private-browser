package com.privatebrowser.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Engine(val id: Long, val name: String, val url: String, val multi: Boolean)
data class Entry(val id: Long, val url: String, val title: String, val time: Long)
data class SavedTab(val url: String, val title: String, val active: Boolean)

/** Local SQLite storage: history, bookmarks, open tabs (session) and search engines. Nothing leaves the device. */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "browser.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, title TEXT, time INTEGER)")
        d.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT UNIQUE, title TEXT, time INTEGER)")
        d.execSQL("CREATE TABLE tabs(pos INTEGER PRIMARY KEY, url TEXT, title TEXT, active INTEGER)")
        d.execSQL("CREATE TABLE engines(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, url TEXT, multi INTEGER)")
        listOf(
            "Google" to "https://www.google.com/search?q=%s",
            "Brave Search" to "https://search.brave.com/search?q=%s",
            "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
            "Yandex" to "https://yandex.com/search/?text=%s"
        ).forEach { (n, u) -> d.insert("engines", null, cv("name" to n, "url" to u, "multi" to 1)) }
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun cv(vararg p: Pair<String, Any?>) = ContentValues().apply {
        p.forEach { (k, v) ->
            when (v) {
                is Long -> put(k, v)
                is Int -> put(k, v)
                is String -> put(k, v)
                else -> putNull(k)
            }
        }
    }

    private fun entries(table: String, order: String, limit: Int): List<Entry> {
        val out = ArrayList<Entry>()
        readableDatabase.query(table, null, null, null, null, null, order, limit.toString()).use { c ->
            while (c.moveToNext()) out += Entry(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("url")) ?: "",
                c.getString(c.getColumnIndexOrThrow("title")) ?: "",
                c.getLong(c.getColumnIndexOrThrow("time"))
            )
        }
        return out
    }

    // ---- history
    fun addHistory(url: String, title: String) {
        val last = entries("history", "id DESC", 1).firstOrNull()
        if (last?.url == url) return
        writableDatabase.insert("history", null, cv("url" to url, "title" to title, "time" to System.currentTimeMillis()))
    }
    fun history(limit: Int = 300) = entries("history", "id DESC", limit)
    fun deleteHistory(id: Long) { writableDatabase.delete("history", "id=?", arrayOf(id.toString())) }
    fun clearHistory() { writableDatabase.delete("history", null, null) }

    // ---- bookmarks
    fun addBookmark(url: String, title: String) {
        writableDatabase.insertWithOnConflict(
            "bookmarks", null, cv("url" to url, "title" to title, "time" to System.currentTimeMillis()),
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }
    fun removeBookmark(url: String) { writableDatabase.delete("bookmarks", "url=?", arrayOf(url)) }
    fun bookmarks(limit: Int = 500) = entries("bookmarks", "id DESC", limit)
    fun isBookmarked(url: String): Boolean =
        readableDatabase.query("bookmarks", arrayOf("id"), "url=?", arrayOf(url), null, null, null).use { it.moveToFirst() }

    // ---- session (open tabs)
    fun saveTabs(t: List<SavedTab>) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.delete("tabs", null, null)
            t.forEachIndexed { i, s ->
                d.insert("tabs", null, cv("pos" to i, "url" to s.url, "title" to s.title, "active" to (if (s.active) 1 else 0)))
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun loadTabs(): List<SavedTab> {
        val out = ArrayList<SavedTab>()
        readableDatabase.query("tabs", null, null, null, null, null, "pos ASC").use { c ->
            while (c.moveToNext()) out += SavedTab(
                c.getString(c.getColumnIndexOrThrow("url")) ?: "",
                c.getString(c.getColumnIndexOrThrow("title")) ?: "",
                c.getInt(c.getColumnIndexOrThrow("active")) == 1
            )
        }
        return out
    }

    // ---- search engines
    fun engines(): List<Engine> {
        val out = ArrayList<Engine>()
        readableDatabase.query("engines", null, null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) out += Engine(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("name")) ?: "",
                c.getString(c.getColumnIndexOrThrow("url")) ?: "",
                c.getInt(c.getColumnIndexOrThrow("multi")) == 1
            )
        }
        return out
    }
    fun addEngine(name: String, url: String) { writableDatabase.insert("engines", null, cv("name" to name, "url" to url, "multi" to 0)) }
    fun updateEngine(id: Long, name: String, url: String) {
        writableDatabase.update("engines", cv("name" to name, "url" to url), "id=?", arrayOf(id.toString()))
    }
    fun deleteEngine(id: Long) { writableDatabase.delete("engines", "id=?", arrayOf(id.toString())) }
    fun setMulti(id: Long, on: Boolean) {
        writableDatabase.update("engines", cv("multi" to (if (on) 1 else 0)), "id=?", arrayOf(id.toString()))
    }
}
