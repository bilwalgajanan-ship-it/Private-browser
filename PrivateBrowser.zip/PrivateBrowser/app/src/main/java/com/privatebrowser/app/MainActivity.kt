package com.privatebrowser.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.PersistableBundle
import android.text.InputType
import android.text.format.DateUtils
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class Tab(val id: Long, val web: WebView, var url: String) {
    var title = "New tab"
    var thumb: Bitmap? = null
    var loaded = false
}

class MainActivity : AppCompatActivity() {

    companion object {
        const val HOME = "https://browser.local/ntp"
        const val INTERNAL = "https://browser.local/"
        const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        val URL_RE = Regex("^(https?://\\S+|about:\\S+|localhost(:\\d+)?([/?#]\\S*)?|([\\w-]+\\.)+[a-zA-Z]{2,}(:\\d+)?([/?#]\\S*)?|(\\d{1,3}\\.){3}\\d{1,3}(:\\d+)?([/?#]\\S*)?)$")
        const val HOOK = "(function(){if(window.__pbHooked)return;window.__pbHooked=true;" +
            "function grab(f){if(!f||!f.querySelector)return;var p=f.querySelector('input[type=password]');if(!p||!p.value)return;" +
            "var u='';var ins=f.querySelectorAll('input[type=text],input[type=email],input[type=tel],input:not([type])');" +
            "for(var i=0;i<ins.length;i++){if(ins[i].value){u=ins[i].value;break;}}PBBridge.onLogin(u,p.value);}" +
            "document.addEventListener('submit',function(e){grab(e.target)},true);" +
            "document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button,input[type=submit]');if(b&&b.form)grab(b.form)},true);})();"
    }

    private lateinit var db: Db
    private lateinit var secure: SecureStore
    private lateinit var prefs: SharedPreferences
    private val tabs = mutableListOf<Tab>()
    private var cur: Tab? = null
    private var nextId = 1L
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var urlBar: EditText
    private lateinit var container: FrameLayout
    private lateinit var progress: ProgressBar
    private lateinit var btnReload: ImageButton
    private lateinit var btnStar: ImageButton
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var tabCount: TextView
    private lateinit var engineBadge: TextView
    private lateinit var fullscreenHolder: FrameLayout

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingDl: (() -> Unit)? = null
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        db = Db(this); secure = SecureStore(this); prefs = getSharedPreferences("settings", MODE_PRIVATE)
        urlBar = findViewById(R.id.urlBar); container = findViewById(R.id.webContainer)
        progress = findViewById(R.id.progress); btnReload = findViewById(R.id.btnReload)
        btnStar = findViewById(R.id.btnStar); btnBack = findViewById(R.id.btnBack); btnForward = findViewById(R.id.btnForward)
        tabCount = findViewById(R.id.tabCount); engineBadge = findViewById(R.id.engineBadge)
        fullscreenHolder = findViewById(R.id.fullscreenHolder)
        CookieManager.getInstance().setAcceptCookie(true)

        urlBar.setOnEditorActionListener { v, _, _ -> navigate(v.text.toString()); urlBar.clearFocus(); hideKb(); true }
        urlBar.setOnFocusChangeListener { _, f -> if (!f) cur?.let { urlBar.setText(display(it.url)) } }
        btnReload.setOnClickListener { if (progress.visibility == View.VISIBLE) cur?.web?.stopLoading() else cur?.web?.reload() }
        btnBack.setOnClickListener { cur?.web?.takeIf { it.canGoBack() }?.goBack() }
        btnForward.setOnClickListener { cur?.web?.takeIf { it.canGoForward() }?.goForward() }
        findViewById<View>(R.id.btnHome).setOnClickListener { load(home()) }
        findViewById<View>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.engineBtn).setOnClickListener { showEngineMenu(it) }
        btnStar.setOnClickListener { toggleBookmark() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack() }
        })

        // Restore previous session (tabs) from local storage
        val saved = db.loadTabs()
        if (saved.isEmpty()) newTab(home()) else {
            saved.forEach { addTab(it.url, it.title) }
            switchTo(tabs[saved.indexOfFirst { it.active }.coerceAtLeast(0)])
        }
        updateBadge()
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.toString()?.let { newTab(it); i.data = null }
    }
    override fun onPause() { super.onPause(); persist(); CookieManager.getInstance().flush(); cur?.web?.onPause() }
    override fun onResume() { super.onResume(); cur?.web?.onResume() }
    override fun onStop() { super.onStop(); persist() }
    private fun persist() { db.saveTabs(tabs.map { SavedTab(it.url, it.title, it === cur) }) }

    private fun goBack() {
        val t = cur ?: return finish()
        when {
            customView != null -> hideCustom()
            t.web.canGoBack() -> t.web.goBack()
            tabs.size > 1 -> closeTab(t)
            else -> finish()
        }
    }

    // ------------------------------------------------------------------ helpers
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun hideKb() { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlBar.windowToken, 0) }
    private fun home() = prefs.getString("home", HOME) ?: HOME
    private fun multiMode() = prefs.getBoolean("multi", false)
    private fun mobileUa() = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
    private fun ua(): String {
        val custom = prefs.getString("customUA", "") ?: ""
        return if (custom.isNotBlank()) custom else if (prefs.getBoolean("desktop", false)) DESKTOP_UA else mobileUa()
    }
    private fun activeEngine(): Engine {
        val l = db.engines()
        return l.firstOrNull { it.id == prefs.getLong("engine", -1) } ?: l.firstOrNull()
            ?: Engine(0, "Google", "https://www.google.com/search?q=%s", false)
    }
    private fun display(url: String) = when {
        url == HOME -> ""
        url.startsWith(INTERNAL + "merged") -> Uri.parse(url).getQueryParameter("q") ?: ""
        else -> url
    }
    private fun updateBadge() { engineBadge.text = if (multiMode()) "M" else activeEngine().name.take(1).uppercase() }
    private fun refreshBar() {
        val t = cur ?: return
        if (!urlBar.hasFocus()) urlBar.setText(display(t.url))
        btnStar.setImageResource(if (db.isBookmarked(t.url)) R.drawable.ic_star else R.drawable.ic_star_border)
        btnBack.alpha = if (t.web.canGoBack()) 1f else 0.4f
        btnForward.alpha = if (t.web.canGoForward()) 1f else 0.4f
    }
    private fun updateCount() { tabCount.text = tabs.size.toString() }

    // ------------------------------------------------------------------ navigation & search
    fun navigate(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val q = URLEncoder.encode(t, "UTF-8")
        val url = when {
            URL_RE.matches(t) -> when {
                t.contains("://") || t.startsWith("about:") -> t
                t.startsWith("localhost") || t.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}.*")) -> "http://$t"
                else -> "https://$t"
            }
            multiMode() -> INTERNAL + "merged?q=" + q
            else -> activeEngine().url.replace("%s", q)   // search terms are passed through untouched
        }
        load(url)
    }
    private fun load(url: String) { cur?.let { it.loaded = true; it.url = url; it.web.loadUrl(url) } }

    // ------------------------------------------------------------------ tabs
    private fun addTab(url: String, title: String): Tab {
        val t = Tab(nextId++, makeWeb(), url)
        t.title = title; t.web.tag = t; tabs += t; updateCount(); return t
    }
    private fun newTab(url: String): Tab { val t = addTab(url, "New tab"); switchTo(t); return t }

    private fun switchTo(t: Tab) {
        cur?.takeIf { it !== t }?.let { capture(it) }
        container.removeAllViews()
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        container.addView(t.web)
        cur = t; urlBar.clearFocus()
        if (!t.loaded) { t.loaded = true; t.web.loadUrl(t.url) }
        progress.visibility = View.INVISIBLE; btnReload.setImageResource(R.drawable.ic_refresh)
        refreshBar(); updateCount()
    }

    private fun closeTab(t: Tab) {
        val i = tabs.indexOf(t); if (i < 0) return
        tabs.removeAt(i)
        if (cur === t) { container.removeAllViews(); cur = null }
        t.web.stopLoading(); ui.post { t.web.destroy() }
        if (tabs.isEmpty()) newTab(home()) else if (cur == null) switchTo(tabs[minOf(i, tabs.size - 1)])
        updateCount()
    }

    private fun capture(t: Tab) {
        try {
            val w = t.web; if (w.width == 0 || w.height == 0) return
            val s = 0.35f
            val bm = Bitmap.createBitmap((w.width * s).toInt(), (w.height * s).toInt(), Bitmap.Config.RGB_565)
            val c = Canvas(bm); c.scale(s, s); w.draw(c); t.thumb = bm
        } catch (e: Throwable) { }
    }

    private fun showTabs() {
        cur?.let { capture(it) }
        val d = Dialog(this, R.style.FullScreenDialog)
        d.setContentView(R.layout.dialog_tabs)
        val list = d.findViewById<RecyclerView>(R.id.tabsList)
        val title = d.findViewById<TextView>(R.id.tabsTitle)
        title.text = "${tabs.size} tabs"
        list.layoutManager = GridLayoutManager(this, 2)
        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = tabs.size
            override fun onCreateViewHolder(p: ViewGroup, type: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_tab, p, false)) {}
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                val t = tabs[i]; val v = h.itemView
                v.findViewById<TextView>(R.id.tabTitle).text = display(t.url).ifBlank { "New tab" }.let { if (t.title.isBlank() || t.title == "New tab") it else t.title }
                v.findViewById<ImageView>(R.id.tabThumb).setImageBitmap(t.thumb)
                (v as MaterialCardView).strokeColor = ContextCompat.getColor(this@MainActivity, if (t === cur) R.color.accent else R.color.divider)
                v.setOnClickListener { switchTo(t); d.dismiss() }
                v.findViewById<View>(R.id.tabClose).setOnClickListener {
                    closeTab(t); notifyDataSetChanged(); title.text = "${tabs.size} tabs"
                }
            }
        }
        list.adapter = adapter
        d.findViewById<View>(R.id.btnNewTab).setOnClickListener { newTab(home()); d.dismiss() }
        d.findViewById<View>(R.id.btnDone).setOnClickListener { d.dismiss() }
        d.show(); d.window?.setLayout(-1, -1)
    }

    // ------------------------------------------------------------------ WebView
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun makeWeb(): WebView {
        val w = WebView(this)
        w.layoutParams = ViewGroup.LayoutParams(-1, -1)
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null)           // hardware acceleration
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true; loadWithOverviewMode = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            allowFileAccess = false; allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = ua()                                  // custom UA routing
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.addJavascriptInterface(Bridge(), "PBBridge")
        w.setDownloadListener { url, agent, cd, mime, _ -> startDownload(url, agent, cd, mime, w.url) }
        w.setOnLongClickListener { v ->
            val r = (v as WebView).hitTestResult
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE, WebView.HitTestResult.IMAGE_TYPE -> {
                    r.extra?.let { linkMenu(it, r.type == WebView.HitTestResult.IMAGE_TYPE) }; true
                }
                else -> false
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == "browser.local" && u.path == "/go") { navigate(u.getQueryParameter("q") ?: ""); return true }
                val s = u.scheme ?: return false
                if (s in listOf("http", "https", "about", "data", "blob", "javascript")) return false
                if (s == "file") return true
                try {
                    val i = if (s == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null
                    } else Intent(Intent.ACTION_VIEW, u)
                    startActivity(i)
                } catch (e: Exception) { }
                return true
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                if (u.host != "browser.local") return null
                val html = when (u.path) {
                    "/ntp" -> ntpHtml()
                    "/merged" -> Merge.page(u.getQueryParameter("q") ?: "", db.engines().filter { it.multi }.ifEmpty { db.engines() }, mobileUa())
                    else -> "<html></html>"
                }
                return WebResourceResponse("text/html", "utf-8", 200, "OK", mapOf("Cache-Control" to "no-store"), ByteArrayInputStream(html.toByteArray()))
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                val t = v.tag as? Tab ?: return
                t.url = url
                if (t === cur) refreshBar()
            }

            override fun onPageFinished(v: WebView, url: String) {
                val t = v.tag as? Tab ?: return
                t.url = url; t.title = v.title ?: url
                val internal = url.startsWith(INTERNAL)
                if (!internal && url.startsWith("http")) {
                    db.addHistory(url, t.title)
                    v.evaluateJavascript(HOOK, null)
                    val host = Uri.parse(url).host ?: return
                    autofill(v, host); ui.postDelayed({ autofill(v, host) }, 1500)
                }
                if (t === cur) refreshBar()
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v.tag !== cur) return
                progress.progress = p
                progress.visibility = if (p < 100) View.VISIBLE else View.INVISIBLE
                btnReload.setImageResource(if (p < 100) R.drawable.ic_close else R.drawable.ic_refresh)
            }
            override fun onReceivedTitle(v: WebView, t: String) { (v.tag as? Tab)?.title = t }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { fileLauncher.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                fullscreenHolder.addView(view); fullscreenHolder.visibility = View.VISIBLE
                WindowInsetsControllerCompat(window, window.decorView).apply {
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    hide(WindowInsetsCompat.Type.systemBars())
                }
            }
            override fun onHideCustomView() { hideCustom() }
            override fun onCreateWindow(v: WebView, isDialog: Boolean, gesture: Boolean, msg: Message): Boolean {
                val t = addTab("about:blank", "New tab"); t.loaded = true; switchTo(t)
                (msg.obj as WebView.WebViewTransport).webView = t.web; msg.sendToTarget(); return true
            }
            override fun onCloseWindow(v: WebView) { (v.tag as? Tab)?.let { closeTab(it) } }
        }
        return w
    }

    private fun hideCustom() {
        val v = customView ?: return
        fullscreenHolder.removeView(v); fullscreenHolder.visibility = View.GONE
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        customCb?.onCustomViewHidden(); customView = null; customCb = null
    }

    private fun linkMenu(url: String, image: Boolean) {
        val items = if (image) arrayOf("Download image", "Copy image URL") else arrayOf("Open in new tab", "Download link", "Copy link")
        AlertDialog.Builder(this).setTitle(url.take(80)).setItems(items) { _, i ->
            val what = items[i]
            when {
                what.startsWith("Open") -> newTab(url)
                what.startsWith("Download") -> startDownload(url, ua(), null, null, cur?.url)
                else -> copy(url, false)
            }
        }.show()
    }
    private fun copy(text: String, sensitive: Boolean) {
        val clip = ClipData.newPlainText("browser", text)
        if (sensitive) clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        toast("Copied")
    }

    // ------------------------------------------------------------------ built-in pages
    private fun ntpHtml(): String {
        val e = activeEngine()
        val tiles = db.bookmarks(8).joinToString("") { b ->
            val h = Uri.parse(b.url).host?.removePrefix("www.") ?: b.url
            "<a class=t href=\"${esc(b.url)}\"><i>${esc(h.take(1).uppercase())}</i><span>${esc(b.title.ifBlank { h }.take(14))}</span></a>"
        }
        return """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
body{font-family:sans-serif;margin:0;padding:48px 20px;text-align:center;background:#fff;color:#202124}
h1{font-weight:400;font-size:34px;margin:40px 0 24px}
input{width:100%;max-width:520px;box-sizing:border-box;padding:14px 20px;border-radius:26px;border:1px solid #dadce0;background:#f1f3f4;font-size:16px;color:inherit;outline:none}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;max-width:520px;margin:32px auto}
.t{text-decoration:none;color:inherit;font-size:12px;display:flex;flex-direction:column;align-items:center;gap:6px}
.t i{width:48px;height:48px;border-radius:50%;background:#e8eaed;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:20px}
@media(prefers-color-scheme:dark){body{background:#202124;color:#e8eaed}input{background:#303134;border-color:#3c4043}.t i{background:#3c4043}}
</style></head><body><h1>Private Browser</h1>
<form action="https://browser.local/go"><input name="q" placeholder="Search with ${esc(e.name)} or type a URL" autocomplete="off"></form>
<div class="g">$tiles</div></body></html>"""
    }

    // ------------------------------------------------------------------ saved logins
    inner class Bridge {
        @JavascriptInterface
        fun onLogin(user: String, pass: String) { runOnUiThread { offerSave(user, pass) } }
    }

    private fun offerSave(user: String, pass: String) {
        val host = Uri.parse(cur?.url ?: return).host ?: return
        if (pass.isEmpty() || secure.get(host, user) == pass) return
        AlertDialog.Builder(this).setTitle("Save password?")
            .setMessage("${user.ifBlank { "(no username)" }} on $host\nStored encrypted on this device only.")
            .setPositiveButton("Save") { _, _ -> secure.save(host, user, pass) }
            .setNegativeButton("Not now", null).show()
    }

    private fun autofill(w: WebView, host: String) {
        val c = secure.forHost(host) ?: return
        val js = """(function(u,p){function set(el,v){var s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;s.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
var pw=document.querySelector('input[type=password]');if(!pw||pw.value)return;
var ins=Array.prototype.slice.call(document.querySelectorAll('input[type=text],input[type=email],input[type=tel],input:not([type])'));
var user=null;for(var i=0;i<ins.length;i++){if(ins[i].compareDocumentPosition(pw)&4){user=ins[i];}}
if(user&&!user.value)set(user,u);set(pw,p);})(${JSONObject.quote(c.user)},${JSONObject.quote(c.pass)});"""
        w.evaluateJavascript(js, null)
    }

    // ------------------------------------------------------------------ downloads
    private fun startDownload(url: String, agent: String?, cd: String?, mime: String?, referer: String?) {
        if (!url.startsWith("http")) { toast("This download type isn't supported"); return }
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDl = { startDownload(url, agent, cd, mime, referer) }
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 7); return
        }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val r = DownloadManager.Request(Uri.parse(url)).setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrEmpty()) r.setMimeType(mime)
            agent?.let { r.addRequestHeader("User-Agent", it) }
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            referer?.takeIf { it.startsWith("http") && !it.startsWith(INTERNAL) }?.let { r.addRequestHeader("Referer", it) }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            toast("Downloading $name")
        } catch (e: Exception) { toast("Download failed: ${e.message}") }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 7 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) pendingDl?.invoke()
        pendingDl = null
    }

    private fun showDownloads() {
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val ids = ArrayList<Long>(); val ok = ArrayList<Boolean>(); val lines = ArrayList<String>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lines)
        val lv = ListView(this); lv.adapter = adapter
        fun refresh() {
            ids.clear(); ok.clear(); lines.clear()
            dm.query(DownloadManager.Query()).use { c ->
                while (c.moveToNext()) {
                    val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    val status = when (st) {
                        DownloadManager.STATUS_SUCCESSFUL -> "Completed · " + Formatter.formatShortFileSize(this, tot)
                        DownloadManager.STATUS_FAILED -> "Failed"
                        DownloadManager.STATUS_PAUSED -> "Paused"
                        DownloadManager.STATUS_PENDING -> "Pending…"
                        else -> (if (tot > 0) "${got * 100 / tot}%" else "…") + "  (" + Formatter.formatShortFileSize(this, got) +
                            (if (tot > 0) " / " + Formatter.formatShortFileSize(this, tot) else "") + ")"
                    }
                    ids += c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
                    ok += (st == DownloadManager.STATUS_SUCCESSFUL)
                    lines += (c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "file") + "\n" + status
                }
            }
            adapter.notifyDataSetChanged()
        }
        val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 700) } }
        lv.setOnItemClickListener { _, _, i, _ ->
            if (ok[i]) try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(dm.getUriForDownloadedFile(ids[i]), dm.getMimeTypeForDownloadedFile(ids[i]))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast("No app can open this file") }
        }
        lv.setOnItemLongClickListener { _, _, i, _ -> dm.remove(ids[i]); refresh(); true }
        val d = AlertDialog.Builder(this).setTitle("Downloads (long-press to delete)").setView(lv).setPositiveButton("Close", null).create()
        d.setOnDismissListener { ui.removeCallbacks(tick) }
        d.show(); tick.run()
    }

    // ------------------------------------------------------------------ menus & dialogs
    private fun listDialog(title: String, items: List<String>, onTap: (Int) -> Unit,
                           onLong: ((Int, AlertDialog) -> Unit)? = null, neutral: Pair<String, () -> Unit>? = null) {
        val b = AlertDialog.Builder(this).setTitle(title).setNegativeButton("Close", null)
        if (items.isEmpty()) b.setMessage("Nothing here yet.") else b.setItems(items.toTypedArray()) { _, i -> onTap(i) }
        neutral?.let { n -> b.setNeutralButton(n.first) { _, _ -> n.second() } }
        val d = b.create(); d.show()
        if (onLong != null && items.isNotEmpty()) d.listView.setOnItemLongClickListener { _, _, i, _ -> onLong(i, d); true }
    }

    private fun prompt(title: String, initial: String, onOk: (String) -> Unit) {
        val e = EditText(this).apply { setText(initial); setSingleLine() }
        val l = FrameLayout(this).apply { setPadding(48, 16, 48, 0); addView(e) }
        AlertDialog.Builder(this).setTitle(title).setView(l)
            .setPositiveButton("OK") { _, _ -> onOk(e.text.toString().trim()) }.setNegativeButton("Cancel", null).show()
    }

    private fun showMenu(a: View) {
        val pm = PopupMenu(this, a); val m = pm.menu
        m.add(0, 1, 0, "New tab"); m.add(0, 2, 1, "History"); m.add(0, 3, 2, "Downloads"); m.add(0, 4, 3, "Bookmarks")
        m.add(0, 5, 4, "Share…"); m.add(0, 6, 5, "Find in page")
        m.add(0, 7, 6, "Desktop site").apply { isCheckable = true; isChecked = prefs.getBoolean("desktop", false) }
        m.add(0, 8, 7, "Settings")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(home())
                2 -> showHistory()
                3 -> showDownloads()
                4 -> showBookmarks()
                5 -> cur?.let { t -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url), "Share")) }
                6 -> @Suppress("DEPRECATION") cur?.web?.showFindDialog(null, true)
                7 -> { prefs.edit().putBoolean("desktop", !it.isChecked).apply(); applyUa(); cur?.web?.reload() }
                8 -> showSettings()
            }
            true
        }
        pm.show()
    }
    private fun applyUa() { tabs.forEach { it.web.settings.userAgentString = ua() } }

    private fun showEngineMenu(a: View) {
        val pm = PopupMenu(this, a); val list = db.engines(); val act = activeEngine()
        list.forEachIndexed { i, e -> pm.menu.add(1, 100 + i, i, e.name).apply { isCheckable = true; isChecked = !multiMode() && e.id == act.id } }
        pm.menu.setGroupCheckable(1, true, true)
        pm.menu.add(2, 1, 50, "Multi-engine search (merge results)").apply { isCheckable = true; isChecked = multiMode() }
        pm.menu.add(2, 2, 51, "Choose engines to merge…")
        pm.menu.add(2, 3, 52, "Edit search engines…")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> { prefs.edit().putBoolean("multi", !multiMode()).apply(); updateBadge(); toast(if (multiMode()) "Merging selected engines" else "Single engine") }
                2 -> multiPicker()
                3 -> manageEngines()
                else -> { prefs.edit().putLong("engine", list[it.itemId - 100].id).putBoolean("multi", false).apply(); updateBadge() }
            }
            true
        }
        pm.show()
    }

    private fun multiPicker() {
        val l = db.engines(); val checked = BooleanArray(l.size) { l[it].multi }
        AlertDialog.Builder(this).setTitle("Engines to merge")
            .setMultiChoiceItems(l.map { it.name }.toTypedArray(), checked) { _, i, c -> checked[i] = c; db.setMulti(l[i].id, c) }
            .setPositiveButton("Enable merge") { _, _ -> prefs.edit().putBoolean("multi", true).apply(); updateBadge() }
            .setNegativeButton("Close", null).show()
    }

    private fun manageEngines() {
        val l = db.engines()
        listDialog("Search engines", l.map { it.name + "\n" + it.url }, { i ->
            val e = l[i]
            AlertDialog.Builder(this).setTitle(e.name).setItems(arrayOf("Set as default", "Edit", "Delete")) { _, w ->
                when (w) {
                    0 -> { prefs.edit().putLong("engine", e.id).putBoolean("multi", false).apply(); updateBadge() }
                    1 -> editEngine(e) { manageEngines(); updateBadge() }
                    2 -> if (l.size <= 1) toast("Keep at least one engine") else { db.deleteEngine(e.id); updateBadge(); manageEngines() }
                }
            }.show()
        }, null, "Add" to { editEngine(null) { manageEngines() } })
    }

    private fun editEngine(e: Engine?, after: () -> Unit) {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }
        val n = EditText(this).apply { hint = "Name"; setText(e?.name ?: "") }
        val u = EditText(this).apply { hint = "https://example.com/search?q=%s"; setText(e?.url ?: ""); inputType = InputType.TYPE_TEXT_VARIATION_URI }
        l.addView(n); l.addView(u)
        AlertDialog.Builder(this).setTitle(if (e == null) "Add search engine" else "Edit search engine")
            .setMessage("Use %s where the search term goes.").setView(l)
            .setPositiveButton("Save") { _, _ ->
                val name = n.text.toString().trim(); var url = u.text.toString().trim()
                if (name.isEmpty() || !url.contains("%s")) { toast("Name and a URL containing %s are required"); return@setPositiveButton }
                if (!url.contains("://")) url = "https://$url"
                if (e == null) db.addEngine(name, url) else db.updateEngine(e.id, name, url)
                after()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun fmtTime(t: Long) = DateUtils.formatDateTime(this, t, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_ALL)

    private fun showHistory() {
        val h = db.history()
        listDialog("History (long-press to delete)", h.map { fmtTime(it.time) + "\n" + it.title.ifBlank { it.url } + "\n" + it.url },
            { load(h[it].url) }, { i, d -> db.deleteHistory(h[i].id); d.dismiss(); showHistory() },
            "Clear all" to { db.clearHistory(); toast("History cleared") })
    }

    private fun showBookmarks() {
        val b = db.bookmarks()
        listDialog("Bookmarks (long-press to delete)", b.map { it.title.ifBlank { it.url } + "\n" + it.url },
            { load(b[it].url) }, { i, d -> db.removeBookmark(b[i].url); d.dismiss(); showBookmarks(); refreshBar() })
    }

    private fun toggleBookmark() {
        val t = cur ?: return
        if (t.url.startsWith(INTERNAL)) { toast("Can't bookmark this page"); return }
        if (db.isBookmarked(t.url)) { db.removeBookmark(t.url); toast("Bookmark removed") } else { db.addBookmark(t.url, t.title); toast("Bookmarked") }
        refreshBar()
    }

    private fun showPasswords() {
        val all = secure.all()
        listDialog("Saved passwords", all.map { it.host + "\n" + it.user.ifBlank { "(no username)" } }, { i ->
            val c = all[i]
            AlertDialog.Builder(this).setTitle(c.host).setItems(arrayOf("Copy password", "Delete")) { _, w ->
                if (w == 0) copy(c.pass, true) else { secure.delete(c); showPasswords() }
            }.show()
        })
    }

    private fun showSettings() {
        val items = arrayOf("Search engines", "Engines to merge (multi-search)", "Homepage", "Custom user agent", "Saved passwords", "Clear browsing data")
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, i ->
            when (i) {
                0 -> manageEngines()
                1 -> multiPicker()
                2 -> prompt("Homepage (blank = new tab page)", prefs.getString("home", "") ?: "") { v ->
                    prefs.edit().putString("home", if (v.isBlank()) HOME else if (v.contains("://")) v else "https://$v").apply()
                }
                3 -> prompt("User agent (blank = default)", prefs.getString("customUA", "") ?: "") { v ->
                    prefs.edit().putString("customUA", v).apply(); applyUa(); cur?.web?.reload()
                }
                4 -> showPasswords()
                5 -> clearData()
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun clearData() {
        val names = arrayOf("Browsing history", "Cookies and site data", "Cached images and files", "Saved passwords", "Bookmarks")
        val on = booleanArrayOf(true, true, true, false, false)
        AlertDialog.Builder(this).setTitle("Clear browsing data")
            .setMultiChoiceItems(names, on) { _, i, c -> on[i] = c }
            .setPositiveButton("Clear") { _, _ ->
                if (on[0]) db.clearHistory()
                if (on[1]) { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData() }
                if (on[2]) tabs.forEach { it.web.clearCache(true) }
                if (on[3]) secure.clear()
                if (on[4]) db.bookmarks().forEach { db.removeBookmark(it.url) }
                refreshBar(); toast("Cleared")
            }.setNegativeButton("Cancel", null).show()
    }
}
