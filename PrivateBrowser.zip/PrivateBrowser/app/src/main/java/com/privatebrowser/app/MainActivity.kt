package com.privatebrowser.app

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.os.Parcel
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

class Tab(val webView: WebView) {
    var title = "New tab"
    var url = ""
    var thumb: Bitmap? = null
    var pendingScroll = 0
    var pendingRec: TabRec? = null
}

class MainActivity : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var engines: Engines
    private lateinit var prefs: Prefs
    private lateinit var defaultUA: String

    private val tabs = mutableListOf<Tab>()
    private var cur = -1

    private lateinit var engineBtn: TextView
    private lateinit var urlInput: EditText
    private lateinit var reloadBtn: ImageButton
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var tabOverlay: View
    private lateinit var tabGrid: RecyclerView
    private lateinit var tabCount: TextView
    private lateinit var fullscreenBox: FrameLayout

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingDl: (() -> Unit)? = null
    private val tabAdapter = TabAdapter()

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
            fileCb = null
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) pendingDl?.invoke() else toast("Storage permission denied")
            pendingDl = null
        }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = Db(this)
        engines = Engines(this)
        prefs = Prefs(this)
        defaultUA = WebSettings.getDefaultUserAgent(this).replace("; wv", "")

        engineBtn = findViewById(R.id.engineBtn)
        urlInput = findViewById(R.id.urlInput)
        reloadBtn = findViewById(R.id.reloadBtn)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        tabOverlay = findViewById(R.id.tabOverlay)
        tabGrid = findViewById(R.id.tabGrid)
        tabCount = findViewById(R.id.tabCount)
        fullscreenBox = findViewById(R.id.fullscreenBox)

        CookieManager.getInstance().setAcceptCookie(true)
        tabGrid.layoutManager = GridLayoutManager(this, 2)
        tabGrid.adapter = tabAdapter

        urlInput.setOnEditorActionListener { v, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                navigate(v.text.toString()); true
            } else false
        }
        engineBtn.setOnClickListener { showEngineMenu() }
        reloadBtn.setOnClickListener {
            val wv = curTab()?.webView ?: return@setOnClickListener
            if (progress.visibility == View.VISIBLE) wv.stopLoading() else wv.reload()
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { curTab()?.webView?.let { if (it.canGoBack()) it.goBack() } }
        findViewById<View>(R.id.btnForward).setOnClickListener { curTab()?.webView?.let { if (it.canGoForward()) it.goForward() } }
        findViewById<View>(R.id.btnHome).setOnClickListener { curTab()?.webView?.loadUrl(prefs.home); hideOverlay() }
        findViewById<View>(R.id.btnDownloads).setOnClickListener { openDownloads() }
        findViewById<View>(R.id.btnTabs).setOnClickListener { toggleOverlay() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu() }
        findViewById<View>(R.id.newTabBtn).setOnClickListener { newTab(prefs.home) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = curTab()?.webView
                when {
                    customView != null -> hideCustom()
                    tabOverlay.visibility == View.VISIBLE -> hideOverlay()
                    wv != null && wv.canGoBack() -> wv.goBack()
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        // Restore last session (lazy: each tab's history is restored when first shown)
        val saved = db.loadTabs()
        if (saved.isEmpty()) {
            newTab(prefs.home)
        } else {
            var active = 0
            saved.forEachIndexed { i, r -> newTab(null, r, false); if (r.active) active = i }
            showTab(active)
        }
        if (savedInstanceState == null) handleIntent(intent)
        updateEngineLabel()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW && i.data != null) newTab(i.dataString)
    }

    override fun onResume() {
        super.onResume()
        tabs.forEach { applySettings(it.webView) }
        updateEngineLabel()
    }

    override fun onPause() {
        super.onPause()
        saveSession()
    }

    override fun onDestroy() {
        tabs.forEach { (it.webView.parent as? ViewGroup)?.removeView(it.webView); it.webView.destroy() }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ session

    private fun saveSession() {
        val list = tabs.mapIndexed { i, t ->
            val state = if (t.pendingRec != null) t.pendingRec!!.state else serialize(t.webView)
            val scroll = if (t.pendingRec != null) t.pendingRec!!.scrollY else t.webView.scrollY
            TabRec(t.url, t.title, scroll, state, i == cur)
        }
        db.saveTabs(list)
    }

    private fun serialize(wv: WebView): ByteArray? {
        val p = Parcel.obtain()
        return try {
            val b = Bundle()
            if (wv.saveState(b) == null) null else {
                p.writeBundle(b)
                p.marshall().takeIf { it.size < 1_500_000 }
            }
        } catch (e: Exception) { null } finally { p.recycle() }
    }

    private fun restoreTab(t: Tab, rec: TabRec) {
        var ok = false
        if (rec.state != null) {
            val p = Parcel.obtain()
            try {
                p.unmarshall(rec.state, 0, rec.state.size)
                p.setDataPosition(0)
                val b = p.readBundle(MainActivity::class.java.classLoader)
                ok = b != null && t.webView.restoreState(b) != null
            } catch (e: Exception) { ok = false } finally { p.recycle() }
        }
        if (!ok && rec.url.isNotEmpty()) t.webView.loadUrl(rec.url)
    }

    // ------------------------------------------------------------------ tabs

    private fun curTab(): Tab? = tabs.getOrNull(cur)

    @Suppress("SetJavaScriptEnabled")
    private fun configure(wv: WebView, tab: Tab) {
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        val s = wv.settings
        s.domStorageEnabled = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportZoom(true)
        s.allowFileAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        applySettings(wv)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, false)
        wv.addJavascriptInterface(Bridge(), "PB")
        wv.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val sc = u.scheme ?: return false
                if (sc in listOf("http", "https", "about", "file", "data", "javascript")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { toast("No app can open this link") }
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.url = url
                if (tab === curTab()) {
                    if (!urlInput.hasFocus()) urlInput.setText(url)
                    progress.visibility = View.VISIBLE
                    reloadBtn.setImageResource(R.drawable.ic_close)
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.url = url
                tab.title = view.title ?: url
                if (url != "about:blank") db.addHistory(url, tab.title)
                view.evaluateJavascript(CAPTURE_JS, null)
                if (tab.pendingScroll > 0) {
                    val y = tab.pendingScroll
                    tab.pendingScroll = 0
                    view.postDelayed({ view.scrollTo(0, y) }, 300)
                }
                if (tab === curTab()) {
                    progress.visibility = View.GONE
                    reloadBtn.setImageResource(R.drawable.ic_refresh)
                    if (!urlInput.hasFocus()) urlInput.setText(url)
                }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                tab.url = url
                if (tab === curTab() && !urlInput.hasFocus()) urlInput.setText(url)
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (tab === curTab()) progress.progress = newProgress
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                if (!title.isNullOrBlank()) tab.title = title
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val t = newTab(null)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = t.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOfFirst { it.webView === window }
                if (i >= 0) closeTab(i)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                fullscreenBox.addView(view)
                fullscreenBox.visibility = View.VISIBLE
                WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() { hideCustom() }

            override fun onShowFileChooser(
                webView: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                try {
                    fileLauncher.launch(params.createIntent())
                } catch (e: Exception) {
                    fileCb = null
                    callback.onReceiveValue(null)
                }
                return true
            }
        }
    }

    private fun hideCustom() {
        if (customView == null) return
        fullscreenBox.removeAllViews()
        fullscreenBox.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun applySettings(wv: WebView) {
        val s = wv.settings
        @Suppress("SetJavaScriptEnabled")
        s.javaScriptEnabled = prefs.js
        s.userAgentString = prefs.effectiveUA(defaultUA)
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
    }

    private fun newTab(url: String?, rec: TabRec? = null, select: Boolean = true): Tab {
        val wv = WebView(this)
        val tab = Tab(wv)
        configure(wv, tab)
        tabs.add(tab)
        if (rec != null) {
            tab.title = rec.title; tab.url = rec.url
            tab.pendingScroll = rec.scrollY
            tab.pendingRec = rec
        } else if (url != null) {
            wv.loadUrl(url)
        }
        if (select) showTab(tabs.size - 1)
        updateTabCount()
        return tab
    }

    private fun attach(i: Int) {
        if (i !in tabs.indices) return
        cur = i
        val t = tabs[i]
        t.pendingRec?.let { t.pendingRec = null; restoreTab(t, it) }
        webContainer.removeAllViews()
        (t.webView.parent as? ViewGroup)?.removeView(t.webView)
        webContainer.addView(t.webView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        urlInput.setText(t.url)
        progress.visibility = View.GONE
        reloadBtn.setImageResource(R.drawable.ic_refresh)
        updateTabCount()
    }

    private fun showTab(i: Int) {
        attach(i)
        tabOverlay.visibility = View.GONE
    }

    private fun closeTab(i: Int) {
        val t = tabs.removeAt(i)
        (t.webView.parent as? ViewGroup)?.removeView(t.webView)
        t.webView.destroy()
        if (tabs.isEmpty()) { cur = -1; newTab(prefs.home); return }
        if (cur > i) cur-- else if (cur == i) cur = minOf(i, tabs.size - 1)
        attach(cur)
        if (tabOverlay.visibility == View.VISIBLE) tabAdapter.notifyDataSetChanged()
    }

    private fun updateTabCount() { tabCount.text = tabs.size.toString() }

    private fun toggleOverlay() {
        if (tabOverlay.visibility == View.VISIBLE) { hideOverlay(); return }
        curTab()?.let { capture(it) }
        tabAdapter.notifyDataSetChanged()
        hideKeyboard()
        tabOverlay.visibility = View.VISIBLE
    }

    private fun hideOverlay() { tabOverlay.visibility = View.GONE }

    private fun capture(t: Tab) {
        try {
            val w = t.webView.width; val h = t.webView.height
            if (w <= 0 || h <= 0) return
            val bmp = Bitmap.createBitmap(w / 3, h / 3, Bitmap.Config.RGB_565)
            val c = Canvas(bmp)
            c.scale(1f / 3, 1f / 3)
            t.webView.draw(c)
            t.thumb = bmp
        } catch (e: Throwable) { }
    }

    inner class TabAdapter : RecyclerView.Adapter<TabAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val title: TextView = v.findViewById(R.id.tabTitle)
            val url: TextView = v.findViewById(R.id.tabUrl)
            val thumb: ImageView = v.findViewById(R.id.tabThumb)
            val close: ImageButton = v.findViewById(R.id.tabClose)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false))

        override fun getItemCount() = tabs.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val t = tabs[position]
            h.title.text = t.title.ifBlank { "New tab" }
            h.url.text = t.url
            h.thumb.setImageBitmap(t.thumb)
            h.itemView.setBackgroundResource(if (position == cur) R.drawable.bg_card_active else R.drawable.bg_card)
            h.itemView.setOnClickListener {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) showTab(p)
            }
            h.close.setOnClickListener {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) closeTab(p)
            }
        }
    }

    // ------------------------------------------------------------------ navigation & search

    private fun navigate(text: String) {
        val u = Search.resolve(text, engines.current(), prefs.home)
        curTab()?.webView?.loadUrl(u)
        urlInput.clearFocus()
        hideKeyboard()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    private fun updateEngineLabel() { engineBtn.text = engines.current().name + " ▾" }

    private fun showEngineMenu() {
        val pm = PopupMenu(this, engineBtn)
        val list = engines.all()
        list.forEachIndexed { i, e ->
            val item = pm.menu.add(0, i, i, e.name)
            item.isCheckable = true
            item.isChecked = i == engines.selected
        }
        pm.menu.add(1, 1000, 1000, "Edit search engines…")
        pm.setOnMenuItemClickListener {
            if (it.itemId == 1000) startActivity(Intent(this, SettingsActivity::class.java))
            else { engines.selected = it.itemId; updateEngineLabel() }
            true
        }
        pm.show()
    }

    // ------------------------------------------------------------------ menu, lists

    private fun showMenu() {
        val t = curTab() ?: return
        val pm = PopupMenu(this, findViewById(R.id.btnMenu))
        pm.menu.add(0, 1, 0, "New tab")
        pm.menu.add(0, 2, 1, if (db.isBookmarked(t.url)) "Remove bookmark" else "Bookmark this page")
        pm.menu.add(0, 3, 2, "Bookmarks")
        pm.menu.add(0, 4, 3, "History")
        pm.menu.add(0, 5, 4, "Saved logins")
        pm.menu.add(0, 6, 5, "Desktop site").apply { isCheckable = true; isChecked = prefs.desktop }
        pm.menu.add(0, 7, 6, "Settings")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(prefs.home)
                2 -> {
                    val on = db.toggleBookmark(t.url, t.title)
                    toast(if (on) "Bookmarked" else "Bookmark removed")
                }
                3 -> showBookmarks()
                4 -> showHistory()
                5 -> showLogins()
                6 -> {
                    prefs.desktop = !prefs.desktop
                    tabs.forEach { tb -> applySettings(tb.webView) }
                    t.webView.reload()
                }
                7 -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        pm.show()
    }

    private fun showRows(
        title: String, rows: List<Row>, empty: String,
        onClick: (Row) -> Unit, onLong: ((Row) -> Unit)?
    ) {
        if (rows.isEmpty()) { toast(empty); return }
        val lv = ListView(this)
        lv.adapter = object : ArrayAdapter<Row>(this, android.R.layout.simple_list_item_2, android.R.id.text1, rows) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val r = rows[position]
                v.findViewById<TextView>(android.R.id.text1).apply { text = r.title.ifBlank { r.sub }; isSingleLine = true }
                v.findViewById<TextView>(android.R.id.text2).apply { text = r.sub; isSingleLine = true }
                return v
            }
        }
        val dlg = AlertDialog.Builder(this).setTitle(title).setView(lv).setNegativeButton("Close", null).create()
        lv.setOnItemClickListener { _, _, pos, _ -> dlg.dismiss(); onClick(rows[pos]) }
        lv.setOnItemLongClickListener { _, _, pos, _ -> dlg.dismiss(); onLong?.invoke(rows[pos]); true }
        dlg.show()
    }

    private fun confirmDelete(what: String, action: () -> Unit, reopen: () -> Unit) {
        AlertDialog.Builder(this).setTitle("Delete $what?")
            .setPositiveButton("Delete") { _, _ -> action(); reopen() }
            .setNegativeButton("Cancel") { _, _ -> reopen() }.show()
    }

    private fun showBookmarks(): Unit = showRows("Bookmarks (long-press to delete)", db.bookmarks(), "No bookmarks yet",
        { curTab()?.webView?.loadUrl(it.sub) },
        { r -> confirmDelete("bookmark", { db.deleteBookmark(r.id) }, { showBookmarks() }) })

    private fun showHistory(): Unit = showRows("History (long-press to delete)", db.history(), "History is empty",
        { curTab()?.webView?.loadUrl(it.sub) },
        { r -> confirmDelete("entry", { db.deleteHistory(r.id) }, { showHistory() }) })

    private fun showLogins() {
        val creds = db.creds()
        val rows = creds.map { Row(it.id, it.user.ifBlank { "(no username)" }, it.host) }
        showRows("Saved logins — tap to fill this page, long-press to delete", rows, "No saved logins",
            { r ->
                val c = creds.first { it.id == r.id }
                val host = Uri.parse(curTab()?.url ?: "").host
                if (host == c.host) {
                    val js = "(function(){var pw=document.querySelector('input[type=password]');if(!pw)return;" +
                        "var f=pw.form||document;var us=f.querySelector('input[type=email],input[type=text],input[type=tel],input:not([type])');" +
                        "function set(el,v){var s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;s.call(el,v);" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}" +
                        "if(us)set(us," + JSONObject.quote(c.user) + ");set(pw," + JSONObject.quote(c.pass) + ");})();"
                    curTab()?.webView?.evaluateJavascript(js, null)
                } else toast("Open ${c.host} first, then tap this login")
            },
            { r -> confirmDelete("login", { db.deleteCred(r.id) }, { showLogins() }) })
    }

    // ------------------------------------------------------------------ password capture

    inner class Bridge {
        @JavascriptInterface
        fun onLogin(url: String, user: String, pass: String) {
            runOnUiThread { offerSave(url, user, pass) }
        }
    }

    private fun offerSave(url: String, user: String, pass: String) {
        val host = Uri.parse(url).host ?: return
        if (pass.isEmpty() || db.credExists(host, user, pass)) return
        AlertDialog.Builder(this)
            .setTitle("Save password?")
            .setMessage("${user.ifBlank { "(no username)" }} @ $host\nStored encrypted on this device only.")
            .setPositiveButton("Save") { _, _ -> db.saveCred(host, user, pass); toast("Saved") }
            .setNegativeButton("Not now", null).show()
    }

    // ------------------------------------------------------------------ downloads

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = { startDownload(url, ua, cd, mime) }
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        if (!url.startsWith("http")) { toast("This download type isn't supported"); return }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                if (!ua.isNullOrBlank()) addRequestHeader("User-Agent", ua)
                curTab()?.url?.takeIf { it.startsWith("http") }?.let { addRequestHeader("Referer", it) }
                if (!mime.isNullOrBlank()) setMimeType(mime)
                setTitle(name)
                setDescription("Private Browser")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                allowScanningByMediaScanner()
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name")
        } catch (e: Exception) {
            toast("Download failed: ${e.message}")
        }
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("No downloads app found") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private val CAPTURE_JS = "(function(){if(window.__pb)return;window.__pb=1;" +
            "function g(f){try{if(!f)return;var p=f.querySelector('input[type=password]');if(!p||!p.value)return;" +
            "var u=f.querySelector('input[type=email],input[type=text],input[type=tel],input:not([type])');" +
            "PB.onLogin(location.href,u?u.value:'',p.value);}catch(e){}}" +
            "document.addEventListener('submit',function(e){g(e.target)},true);" +
            "document.addEventListener('click',function(e){var b=e.target.closest?e.target.closest('button,input[type=submit]'):null;" +
            "if(b&&b.form)g(b.form)},true);})();"
    }
}
