package com.privatebrowser.app

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * A random 256-bit field key lives inside EncryptedSharedPreferences (protected by an
 * Android Keystore MasterKey). Passwords in SQLite are AES-GCM encrypted with that key.
 */
object Vault {
    private var cached: SecretKeySpec? = null

    private fun prefs(ctx: Context): SharedPreferences {
        val mk = MasterKey.Builder(ctx.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            ctx.applicationContext, "vault", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    @Synchronized
    private fun key(ctx: Context): SecretKeySpec {
        cached?.let { return it }
        val p = prefs(ctx)
        var b64 = p.getString("dbkey", null)
        if (b64 == null) {
            val k = ByteArray(32)
            SecureRandom().nextBytes(k)
            b64 = Base64.encodeToString(k, Base64.NO_WRAP)
            p.edit().putString("dbkey", b64).apply()
        }
        val spec = SecretKeySpec(Base64.decode(b64, Base64.NO_WRAP), "AES")
        cached = spec
        return spec
    }

    fun enc(ctx: Context, plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(ctx))
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun dec(ctx: Context, data: String): String {
        val all = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(ctx), GCMParameterSpec(128, all, 0, 12))
        return String(c.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
    }
}
