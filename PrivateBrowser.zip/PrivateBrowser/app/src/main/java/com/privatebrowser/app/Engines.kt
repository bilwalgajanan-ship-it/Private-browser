package com.privatebrowser.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class Engine(val name: String, val url: String)

class Engines(ctx: Context) {
    private val p = ctx.getSharedPreferences("engines", Context.MODE_PRIVATE)

    private val defaults = listOf(
        Engine("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
        Engine("Brave", "https://search.brave.com/search?q=%s"),
        Engine("Bing", "https://www.bing.com/search?q=%s"),
        Engine("Google", "https://www.google.com/search?q=%s"),
        Engine("SearXNG", "https://searx.be/search?q=%s")
    )

    fun all(): MutableList<Engine> {
        val s = p.getString("list", null)
        if (s != null) {
            try {
                val a = JSONArray(s)
                val out = mutableListOf<Engine>()
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Engine(o.getString("name"), o.getString("url")))
                }
                if (out.isNotEmpty()) return out
            } catch (e: Exception) { }
        }
        return defaults.toMutableList()
    }

    fun save(l: List<Engine>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("name", it.name).put("url", it.url)) }
        p.edit().putString("list", a.toString()).apply()
    }

    var selected: Int
        get() = p.getInt("sel", 0)
        set(v) { p.edit().putInt("sel", v).apply() }

    fun current(): Engine {
        val l = all()
        return l[selected.coerceIn(0, l.size - 1)]
    }
}

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var home: String
        get() = p.getString("home", "https://duckduckgo.com") ?: "https://duckduckgo.com"
        set(v) { p.edit().putString("home", v).apply() }
    var ua: String
        get() = p.getString("ua", "") ?: ""
        set(v) { p.edit().putString("ua", v).apply() }
    var desktop: Boolean
        get() = p.getBoolean("desktop", false)
        set(v) { p.edit().putBoolean("desktop", v).apply() }
    var js: Boolean
        get() = p.getBoolean("js", true)
        set(v) { p.edit().putBoolean("js", v).apply() }

    fun effectiveUA(default: String): String = when {
        ua.isNotBlank() -> ua
        desktop -> DESKTOP_UA
        else -> default
    }

    companion object {
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}

object Search {
    private val scheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")
    private val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")

    /** No filtering: whatever is typed goes verbatim (URL-encoded) to the selected engine. */
    fun resolve(input: String, engine: Engine, home: String): String {
        val t = input.trim()
        if (t.isEmpty()) return home
        if (t.startsWith("about:")) return t
        if (scheme.matches(t)) return t
        if (!t.contains(' ')) {
            if (ip.matches(t) || t.startsWith("localhost")) return "http://$t"
            if (t.contains('.')) return "https://$t"
        }
        return engine.url.replace("%s", URLEncoder.encode(t, "UTF-8"))
    }
}
