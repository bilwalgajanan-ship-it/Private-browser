# Private Browser (Android, Kotlin)
1. Create a GitHub repo and push this folder (keep the `.github` folder).
2. Open the **Actions** tab -> "Build debug APK" runs automatically (or run it manually).
3. Download `PrivateBrowser-debug-apk` from the run's Artifacts, unzip, install `app-debug.apk`.
Local build: open in Android Studio (Koala+), or run `gradle assembleDebug`.
