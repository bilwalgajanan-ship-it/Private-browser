# Private Browser (Android)
Local-only WebView browser. No telemetry, no sync, Safe Browsing disabled.

## Build the APK with GitHub Actions
1. Create a new GitHub repo and push this folder to the `main` branch.
2. Open the repo -> Actions -> "Build APK". When it finishes, download the
   `PrivateBrowser-debug-apk` artifact, or grab `PrivateBrowser-debug.apk` from the Releases page.
3. Install the APK on your phone (allow "install unknown apps").

## Local build
Open in Android Studio (Koala+ / JDK 17) and run, or: `gradle assembleDebug`.
